# **********************************
# ORDENANDO IDS EN UNA BASE DE DATOS
# # **********************************


def sort_id(data_base: list) -> list:
    data_base_c = data_base.copy()
    for i, entry in enumerate(data_base_c):
        entry["id"] = i + 1
    return data_base_c
