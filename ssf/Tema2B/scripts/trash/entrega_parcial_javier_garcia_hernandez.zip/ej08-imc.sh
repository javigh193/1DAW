#!/bin/bash

#############################################################
#
# Nombre: ej08-imc.sh
# Objetivo: calcular el índice de masa corporal
# Autor: Javier García <javigh1903@movistar.es>
#
# Argumentos: total=2, 1-altura, 2-peso
# Salida: imc y clasificación según OMS
# Fecha: 31.01.2023
# Versiónes: 1.0 (código inicial)
#
##############################################################
if [ $# -ne 2 ]
then
    echo "Error: parámetros incorrectos"
    echo "Indicar altura en cm y peso en kg"
    exit
fi
altura=$1
peso=$2
imc=$(bc<<<10000*$peso/$altura**2)
echo "$imc"
if (($imc < 18,50))
then
    echo "Un imc de $imc sugiere un peso bajo"
elif (($imc > 18,50 && $imc < 25,00))
then
    echo "Un imc de $imc sugiere un peso normal"
elif (($imc >= 25,00 && $imc < 30))
then    
    echo "Un imc de $imc sugiere sobrepeso"
else
    echo "Un imc de $imc sugiere obesidad"
fi
