The ant utility (http://ant.apache.org/) will compile and run ImageJ using 
the build file (build.xml) in this directory.